# Intelligent Text-to-SQL Agent — Concept Demo

A **simulated** Streamlit interface for discussing the proposed NLP course project with teammates. It includes three example questions, illustrative SQL, sample HR data and charts. **It does not connect to a database or AI model.**

## Run locally

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Share a public URL

1. Create a GitHub repository and upload `app.py` and `requirements.txt` to its root.
2. Sign in to [Streamlit Community Cloud](https://share.streamlit.io/).
3. Select **Create app**, choose your GitHub repository, branch and `app.py`, then deploy.
4. Copy the public URL and send it to your teammates.

The public URL is created by Streamlit Community Cloud after deployment, not by this ZIP file.
